Iconic One Read Me:

To setup the theme simply visit live customizer.

For updated FAQs and informatin on latest version visit official theme page 

http://themonic.com/iconic-one/

For support visit 

https://wordpress.org/support/theme/iconic-one

For urgent support visit

http://themonic.com/support/